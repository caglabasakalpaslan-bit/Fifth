#!/usr/bin/env python3
"""Sıkıştırmayı sınar. API gerektirmez.

    python3 arac/sina.py

Ölçtükleri:
 1 ayırt edicilik   — iki söz aynı iskelete mi çöküyor
 2 geri dönüş       — iskelet tek bir söze mi işaret ediyor
 3 mekanizma        — etiketler süs mü, gerçek küme mi
 4 eksen bağımsızlığı — p ve z birbirinden ayrı bilgi mi taşıyor
 5 sızıntı          — iskelette somut isim kalmış mı
 6 çelişki geometrisi — çelişenler eksenin karşı yanında mı
"""
import json, math, random, re, sys, pathlib, warnings
warnings.filterwarnings("ignore")
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

kok = pathlib.Path(__file__).resolve().parent.parent
d = json.load(open(kok/"veri/atasozleri.json", encoding="utf-8"))
D, C = d["kayitlar"], d.get("ciftler", [])
idx = {r["id"]: i for i, r in enumerate(D)}
N = len(D)
gecti = []

def baslik(n, ad): print(f"\n{'─'*66}\n{n}. {ad}\n")
def sonuc(ok, mesaj):
    gecti.append(ok)
    print(f"\n  {'GEÇTİ ' if ok else 'DİKKAT'} · {mesaj}")

# Metin temsili: iskelet + işlev, karakter n-gram (Türkçe eklemeli)
V = TfidfVectorizer(analyzer="char_wb", ngram_range=(3,5), min_df=1, sublinear_tf=True)
X = V.fit_transform([r["i"] + " " + r["f"] for r in D])
S = cosine_similarity(X); np.fill_diagonal(S, -1)

# ── 1. Ayırt edicilik ────────────────────────────────────────────────
baslik(1, "Ayırt edicilik — iki farklı söz aynı iskelete mi çöküyor?")
cift = [(S[i,j], i, j) for i in range(N) for j in range(i+1, N)]
cift.sort(reverse=True)
print("  en çok benzeşen beş iskelet çifti:")
for s, i, j in cift[:5]:
    print(f"    {s:.2f}  {D[i]['s'][:32]:<32} ↔ {D[j]['s'][:32]}")
cakisan = sum(1 for s,_,_ in cift if s > 0.60)
print(f"\n  0,60 üstü çakışma: {cakisan} çift / {len(cift)}")
sonuc(cakisan <= N*0.02, f"iskeletler birbirinden ayrışıyor ({cakisan} çakışma)")

# ── 2. Geri dönüş belirsizliği ───────────────────────────────────────
baslik(2, "Geri dönüş — iskelet tek bir söze mi işaret ediyor?")
en_yakin = S.max(axis=1)
ikinci = np.sort(S, axis=1)[:, -2]
marj = en_yakin - ikinci          # birinci ile ikinci arası fark
belirsiz = [i for i in range(N) if en_yakin[i] > 0.5 and marj[i] < 0.05]
print(f"  ortalama en yakın komşu benzerliği : {en_yakin.mean():.3f}")
print(f"  birinci–ikinci marjı ortalaması    : {marj.mean():.3f}")
if belirsiz:
    print(f"\n  belirsiz kalan {len(belirsiz)} iskelet:")
    for i in belirsiz[:5]: print(f"    {D[i]['s'][:52]}")
sonuc(len(belirsiz) <= N*0.05, f"{len(belirsiz)} iskelet belirsiz")

# ── 3. Mekanizma etiketleri gerçek mi? ───────────────────────────────
baslik(3, "Mekanizma — etiketler süs mü, gerçek küme mi?")
mek = {}
for i, r in enumerate(D): mek.setdefault(r["m"], []).append(i)
ici, disi = [], []
for m, uy in mek.items():
    if len(uy) < 2: continue
    for a in range(len(uy)):
        for b in range(a+1, len(uy)): ici.append(S[uy[a], uy[b]])
random.seed(0)
for _ in range(4000):
    i, j = random.sample(range(N), 2)
    if D[i]["m"] != D[j]["m"]: disi.append(S[i, j])
ici, disi = np.array(ici), np.array(disi)
oran = ici.mean()/disi.mean()
print(f"  aynı mekanizma içi benzerlik : {ici.mean():.3f}  (n={len(ici)})")
print(f"  farklı mekanizma arası       : {disi.mean():.3f}")
print(f"  oran                         : {oran:.2f}×")
sonuc(oran >= 1.15, f"etiketler gerçek kümeye karşılık geliyor ({oran:.2f}×)")

# ── 4. Eksenler bağımsız mı? ─────────────────────────────────────────
baslik(4, "Eksen bağımsızlığı — p ve z ayrı bilgi mi taşıyor?")
P = np.array([r["p"] for r in D]); Z = np.array([r["z"] for r in D])
r_pz = np.corrcoef(P, Z)[0,1]
r_apz = np.corrcoef(np.abs(P), Z)[0,1]
print(f"  p ↔ z korelasyonu       : {r_pz:+.3f}")
print(f"  |p| ↔ z korelasyonu     : {r_apz:+.3f}")
# mekanizma z'yi ne kadar açıklıyor
gr = [Z[uy] for uy in mek.values() if len(uy) >= 3]
ss_ici = sum(((g-g.mean())**2).sum() for g in gr)
ss_top = ((Z-Z.mean())**2).sum()
print(f"  mekanizma z varyansının  : %{(1-ss_ici/ss_top)*100:.0f}'ini açıklıyor")
sonuc(abs(r_pz) < 0.35, f"p ve z bağımsız (r={r_pz:+.2f})")

# ── 5. Sızıntı ───────────────────────────────────────────────────────
baslik(5, "Sızıntı — iskelette somut isim kalmış mı?")
SOMUT = ("ateş kuş horoz yorgan deniz ağaç gül diken bal arı kedi köpek kurt "
         "koyun tavuk yumurta ekmek çuval testi değirmen kervan deve balık "
         "soğan üzüm demir mum akçe komşu terzi imam derviş aslan tilki "
         "saksağan minare fincan kahve karpuz koltuk yastık ayı tencere").split()
sz = [(r["id"], w) for r in D for w in SOMUT
      if re.search(rf"(?<![a-zçğıöşü]){w}(?![a-zçğıöşü])", r["i"].lower())]
for i, w in sz[:6]: print(f"    {i}: '{w}'")
if not sz: print("    yok")
sonuc(len(sz) == 0, f"{len(sz)} sızıntı")

# ── 6. Çelişki geometrisi ────────────────────────────────────────────
baslik(6, "Çelişki geometrisi — çelişenler eksenin karşı yanında mı?")
SIRA = ["MEKAN","ILISKI","IS","PARA","ANLAM","BEDEN","DUYGU","ZIHIN"]
ACI = {p: 2*math.pi*i/8 for i, p in enumerate(SIRA)}
def yer(r):
    a = ACI[r["k"][0]]
    if len(r["k"]) > 1:
        a += ((ACI[r["k"][1]]-a+math.pi) % (2*math.pi) - math.pi)/3
    return np.array([r["p"]*math.cos(a), r["p"]*math.sin(a)])
Y = {r["id"]: yer(r) for r in D}
def oran_ek(a, b):
    A, B = Y[a], Y[b]; v = B-A; L = v@v
    t = 0.0 if L == 0 else max(0, min(1, -(A@v)/L))
    ort = (np.linalg.norm(A)+np.linalg.norm(B))/2
    return np.linalg.norm(A+t*v)/ort if ort > 1e-9 else None
co = [x for x in (oran_ek(p["a"], p["b"]) for p in C) if x is not None]
guclu = [r["id"] for r in D if abs(r["p"]) >= 0.4]
random.seed(1)
ro = [x for x in (oran_ek(*random.sample(guclu, 2)) for _ in range(5000)) if x is not None]
print(f"  çelişki çiftleri  : {np.mean(co):.3f}   (0 = tam karşıt)")
print(f"  eşleşmiş rastgele : {np.mean(ro):.3f}")
print(f"  oran              : {np.mean(ro)/np.mean(co):.2f}×   (n={len(co)} çift)")
sonuc(np.mean(ro)/np.mean(co) >= 1.2,
      f"eğilim var ama n={len(co)} az; 60+ çiftte tekrar bak")

print(f"\n{'═'*66}\n{sum(gecti)}/{len(gecti)} sınama geçti\n")
sys.exit(0 if all(gecti) else 1)
