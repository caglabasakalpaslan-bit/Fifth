#!/usr/bin/env python3
"""Ham listeyi sınıflandırır. Kesilirse kaldığı yerden devam eder.

    pip install anthropic
    export ANTHROPIC_API_KEY=sk-...

    python3 arac/tara.py --kuru --adet 8   # PARA HARCAMAZ, ne gönderileceğini gösterir
    python3 arac/tara.py --adet 40         # 40 söz işle, dur, çıktıya bak
    python3 arac/tara.py --adet 40 --iki   # her sözü iki kez oku, uyuşmazlığı ayır
    python3 arac/tara.py                   # kalan hepsi

Çıktı  : veri/taranan.jsonl
Ayrılan: veri/celiskili.jsonl   (--iki modunda uyuşmayanlar, elle bakılır)
Sonra  : python3 arac/birlestir.py && python3 arac/dogrula.py veri/atasozleri.json
"""
import json, os, sys, time, pathlib, argparse, random

kok = pathlib.Path(__file__).resolve().parent.parent
MODEL = "claude-sonnet-5"
KUTUP = {"MEKAN","ILISKI","ZIHIN","IS","DUYGU","PARA","BEDEN","ANLAM"}

ap = argparse.ArgumentParser()
ap.add_argument("--adet",  type=int, default=0, help="kaç yeni söz işlensin (0 = hepsi)")
ap.add_argument("--parti", type=int, default=8, help="tek istekte kaç söz")
ap.add_argument("--iki",   action="store_true", help="her sözü iki kez oku")
ap.add_argument("--kuru",  action="store_true", help="istek atma, ne gönderileceğini göster")
a = ap.parse_args()

prompt = open(kok/"prompt/01-siniflandirici.md", encoding="utf-8").read()
ham    = json.load(open(kok/"veri/ham_liste.json", encoding="utf-8"))["kayitlar"]
sema   = json.load(open(kok/"veri/atasozleri.json", encoding="utf-8"))
elle   = {r["s"] for r in sema["kayitlar"]}
MEK    = set(sema["mekanizmalar"])

cikti, bitmis = kok/"veri/taranan.jsonl", set()
if cikti.exists():
    for satir in open(cikti, encoding="utf-8"):
        try: bitmis.add(json.loads(satir)["s"])
        except Exception: pass

kalan = [k for k in ham if k["s"] not in elle and k["s"] not in bitmis]
if a.adet: kalan = kalan[:a.adet]
parti_sayisi = (len(kalan) + a.parti - 1) // a.parti
print(f"{len(bitmis)} bitmiş · {len(kalan)} işlenecek · {parti_sayisi} parti · "
      f"{parti_sayisi*(2 if a.iki else 1)} API çağrısı · model {MODEL}")
if not kalan: sys.exit(0)

def girdi_metni(parti):
    return "\n".join(
        f"{i+1}. {k['s']}" + (f"   [anlamı: {k['anlam'][0][:180]}]" if k["anlam"] else "")
        for i, k in enumerate(parti))

if a.kuru:
    p = kalan[:a.parti]
    print("\n"+"-"*66+"\nSİSTEM PROMPTU (son 300 karakter)\n"+"-"*66)
    print("..."+prompt[-300:])
    print("\n"+"-"*66+f"\nİLK PARTİ ({len(p)} söz)\n"+"-"*66)
    print(girdi_metni(p))
    print("\n"+"-"*66+"\nBEKLENEN ÇIKTI\n"+"-"*66)
    print('[{"s":"...","k":["IS"],"p":-0.6,"z":0.5,"m":"hiz-kalite","i":"...","f":"..."}]')
    print("\nÇağrı yapılmadı. Gerçekten çalıştırmak için --kuru bayrağını kaldır.")
    sys.exit(0)

from anthropic import Anthropic
ist = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

def oku(parti, deneme=3):
    for d in range(deneme):
        try:
            y = ist.messages.create(
                model=MODEL, max_tokens=4000,
                system=prompt + "\n\nSana numaralı bir liste verilecek. Her satır için tam olarak "
                       "bir JSON nesnesi üret; hepsini tek bir JSON dizisi içinde, girdiyle AYNI "
                       "SIRADA döndür. Dizi dışında hiçbir şey yazma. Bir satırı sınıflandıramazsan "
                       "bile o satır için bir nesne üret.",
                messages=[{"role": "user", "content": girdi_metni(parti)}])
            m = "".join(b.text for b in y.content if b.type == "text").strip()
            m = m.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
            r = json.loads(m)
            if len(r) != len(parti):
                raise ValueError(f"{len(parti)} gönderildi, {len(r)} döndü")
            for x, k in zip(r, parti): x["s"] = k["s"]   # orijinal metni koru
            return r
        except Exception as e:
            if d == deneme-1: raise
            bekle = 2**d + random.random()
            print(f"\n  yeniden deneniyor ({type(e).__name__}) - {bekle:.1f}s")
            time.sleep(bekle)

def gecerli(x):
    try:
        if not (1 <= len(x["k"]) <= 2): return False
        if any(p not in KUTUP for p in x["k"]): return False
        if not -1 <= float(x["p"]) <= 1: return False
        if not  0 <= float(x["z"]) <= 1: return False
        if x["m"] not in MEK and x["m"] != "?": return False
        if len(x["i"]) < 15 or len(x["f"]) < 5: return False
        return True
    except Exception:
        return False

def yaz(yol, kayitlar):
    with open(yol,"a",encoding="utf-8") as f:
        for r in kayitlar: f.write(json.dumps(r,ensure_ascii=False)+"\n")

islenen=atilan=hatali=uyusmayan=0
for i in range(0,len(kalan),a.parti):
    parti = kalan[i:i+a.parti]
    try:
        r1 = oku(parti)
        if a.iki:
            r2 = {x["s"]:x for x in oku(parti)}
            tut=[]
            for x in r1:
                y = r2.get(x["s"])
                if y is None: continue
                ok = (abs(x["p"]-y["p"])<=0.2 and abs(x["z"]-y["z"])<=0.2 and x["m"]==y["m"])
                x["tutarli"]=ok
                if ok: tut.append(x)
                else:
                    x["ikinci"]={"p":y["p"],"z":y["z"],"m":y["m"]}
                    uyusmayan+=1; yaz(kok/"veri/celiskili.jsonl",[x])
            r1 = tut
        temiz=[x for x in r1 if gecerli(x)]
        atilan += len(r1)-len(temiz)
        yaz(cikti,temiz); islenen+=len(temiz)
    except Exception as e:
        hatali+=1
        print(f"\n  parti atlandı: {type(e).__name__} {str(e)[:80]}")
        time.sleep(3)
    print(f"\r{islenen}/{len(kalan)} yazıldı · {atilan} bozuk · {hatali} parti hatası"
          + (f" · {uyusmayan} uyuşmayan" if a.iki else ""), end="", flush=True)

print(f"\n\nbitti -> veri/taranan.jsonl")
if a.iki: print(f"uyuşmayanlar -> veri/celiskili.jsonl · {uyusmayan} kayıt, elle bak")
print("sonra: python3 arac/birlestir.py && python3 arac/dogrula.py veri/atasozleri.json")
