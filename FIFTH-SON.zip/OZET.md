# The Fifth / Fifthback — çalışma özeti

## Elde ne var

| dosya | içerik |
|---|---|
| `veri/ham_liste.json` | **3114 atasözü**, 2271'inin TDK/Wiktionary açıklamasıyla |
| `veri/atasozleri.json` | **100 elle kodlanmış kayıt** + 15 çelişki çifti + ayırt edici sorular |
| `veri/dillerarasi.json` | 8 iskelet, 9 dil, 23 yabancı eş |
| `cikmaz/cikmazlar.json` | **38 çıkmaz · 152 yol · 152 "yetmez" satırı** |
| `vaka/vakalar.json` | 12 tarafsızlaştırılmış vaka, dört açıyla |
| `arac/` | çekme, tarama, doğrulama, sınama, build, 8 görselleştirme |

## Şema

**Atasözü kaydı** — s (yüzey) · k (kutup, 8'li) · p (polarite −1..+1) ·
z (yaşamadan anlaşılabilirlik 0..1) · m (mekanizma, 17'li kapalı liste) ·
i (iskelet: somut isim içermeyen hali) · f (işlev) · c (çelişki bağı)

**Çıkmaz kaydı** — iki kapalı yön + her birinin maliyeti ve tehdit ettiği ihtiyaç ·
iskelet · ayırt edici soru · çıkış koşulu · seviye (10/20/30/40) ·
dört yol, her yolda ne / işe yarar / **yetmez**

## Bulgular

**Tutanlar**

- Çelişen atasözü çiftleri ayırt edici sorunun kaynağı. İki söz birbirini
  yalanlıyorsa aralarında karar veren şey zorunlu olarak ayırt edici bir sorudur.
- Çıkmaz dilde ayrı gramerle işaretleniyor: "ya…ya", "ne…ne", "…mi…mi".
  3114 kayıtta 49 aday.
- İskelet dil-bağımsız. 8 iskeletin 8'inde yabancı eş bulundu; imgelerin %48'i
  farklı, %30'u aynı. Sıkışma ortak, giydirme yerel.
- Seviye 40'ta uçurum var: z ortalaması 10→0,54 · 20→0,53 · 30→0,57 · **40→0,72**.
  İlk üç katman anlatılarak aktarılır, dördüncüsü aktarılamaz. (p<0,001)
- Kalıcı homoloji: 100 noktalı bulutta **bir kalıcı döngü** (ömür 1,208,
  gürültü eşiği 0,661). Rastgele bulutta en uzun ömür 0,181 — 7 kat fark.
- Gerçek boyut sayısı **4**. Beş eksen yazıldı, bilginin %91'i dört boyutta.
- 38 çıkmazın 20'si kıtlık dünyasında yoktu. O 20'nin **13'ü görünürlükten**,
  5'i seçenek bolluğundan doğuyor.
- Çıkmazların tehdit ettiği ihtiyaçlar: bağ 23 · anlam 22 · güvenlik 15 ·
  saygı 10 · **beden 6**. Piramidin sıralama iddiası bu veride tutmuyor.

**Çökenler (dürüstlük kaydı)**

- TDK açıklamalarından kural tabanlı polarite çıkarma: işaret tutarlılığı %42,
  yazı turadan kötü. Açıklama anlamı taşıyor, yönü taşımıyor.
- Dört işlem (+ − × ÷) ile Türkçe hal ekleri eşleşmesi: 4'te 2.
- İhtiyaç farkı ↔ çözülemezlik: korelasyon −0,15, p=0,43. Gürültü.
- Kutup sayısını kümelemeyle veriden bulma: 100 kayıtta hiçbir k değeri
  diğerinden iyi çıkmadı. 500+ kayıt gerekiyor.

## Kavramlar

- **İskelet** — sözün somut isim içermeyen hali. Topolojik değişmez.
  Aynı iskelet farklılığı çürütür, aynılığı kanıtlamaz.
- **Çıkmaz** — bir çelişki çiftinin tek kişide aynı anda yaşanması.
  Kasılamayan döngü: yollar yüzeyi esnetir, delik yerinde kalır.
- **Beşinci soru** — sistemin gerçekten bilmediği yer. İki tarafı da yüksek
  puan alan çelişki çiftinin sorusu. Bilgi eklemez, ikiye indirir.
- **Delta** — aynı çıkmaza ikinci kez girildiğinde ne değiştiği.
  Sistemin zaman hakkında dürüstçe ölçebildiği tek şey.
- **Kayan origin** — her üçgen bir öncekinin ucundan başlar. Kişi merkezde
  durmaz, merkezi taşır.

## Kararlar

- Sekiz kutup **donduruldu**. Doğru oldukları için değil, 100 kayıtla daha
  iyisini bilemediğimiz için. Tarama bitince açılır.
- Skor, sıralama, yüzde **yok**. "3 kişiden 2'si" denir, "%67" denmez.
- İç etiketler (çıkmaz adı, mekanizma, katman) kullanıcıya **gösterilmez**.
  Kişi kendi cümlesini görür.
- Kolektif eğilim uydurulmaz, **atasözlerinin ortalama polaritesinden** gelir.
  Kullanıcı seçimleri onu günceller.
- Hedef kitle: **bilgi eksikliğinden değil fazlasından tükenmiş insan.**
  Her tasarım kararı tek soruyla sınanır — seçenek ekliyor mu, azaltıyor mu?
- Giriş ücreti yok. Filtre para değil, **dönüş**.
- İK'ya profil satmak, finansal sinyal satmak, teşhis koymak: reddedildi.

## Ürün

Dar akış — bir dert, iki soru, dört yol. Beş dakika.
`kapı → onay → beşinci soru → dört yol → seçim → dönüş`

Geniş alan — havuz, düello, defter. Saatlerce kalınabilir, çünkü burada
kişi karar vermez, başkasının kararına bakar.

## Sırada

1. Vaka havuzunu 12'den 60-80'e çıkarmak
2. Delta mekanizması — aynı çıkmaza ikinci giriş
3. Düello — iki kişi, aynı vaka, ayrı cevap
4. `arac/tara.py --adet 40 --iki` (API anahtarı gerekiyor)
